<?php include_once("./head.php"); ?>
<?php include_once("./navbar.php"); ?>

<form method="post" enctype='multipart/form-data'>
<table border="2px" align="center" width="400px" cellspacing="0px">
            <tr><th colspan="2">Teacher's Registration Form</th></tr>
            <!-- <tr><td>Rollno</td><td><input name="roll" size="15" type="number" pattern="[0-9]{3,}"></td></tr> -->
            <tr><td>Name</td><td><input name="nm" placeholder="Enter name" size="15"></td></tr>
            <tr><td>Email</td><td><input name="em" type="email"></td></tr>
            <tr><td>Password</td><td><input name="pwd" type="password" minlength="8" maxlength="12"></td></tr>
            <tr>
                <td> </td>
                <td><input type="submit" name="subBtn" value="Insert Record">
                </td>
            </tr>
</table>
<?php

extract($_POST);
if(isset($subBtn))
{
    echo "works";
     include_once("./db_conn.php");
     $link=mysqli_connect($hostname,$username,$password,$databasename);
     $qry="insert into teachers(name,mail,pin)values('$nm','$em','$pwd')";
    $r=mysqli_query($link,$qry);
    mysqli_close($link);
    if($r==1)
    {
        echo "<div class='alert alert-success' role='alert'><br> <h4>Record Updated..</h4></div>";
    }
    else
    {
        echo "<div class='alert alert-success' role='alert'><br> <h4>Failure..</h4></div>";
    }

}

?>
</form>


<?php 
include_once("./foot.php"); 
?>