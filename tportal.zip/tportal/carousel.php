<div id="carouselExampleSlidesOnly" class="carousel slide" data-ride="carousel" data-interval='1500'>
  <div class="carousel-inner">
    <div class="carousel-item active" align='center'>
        <img src="./Logo/c1.png" class="d-block w-50" alt="..." align='center'>
    </div>
    <div class="carousel-item" align='center'>
      <img src="./Logo/c2.png" class="d-block w-50" alt="..." align='center'>
    </div>
    <div class="carousel-item" align='center'>
      <img src="./Logo/c3.png" class="d-block w-50" alt="..." align='center'>
    </div>
    <div class="carousel-item" align='center'>
      <img src="./Logo/c4.png" class="d-block w-50" alt="..." align='center'>
    </div>
  </div>
</div>