<?php include_once("./head.php"); ?>
<?php include_once("./navbar.php"); ?>
<?php
include_once("./db_conn.php");
     $link=mysqli_connect($hostname,$username,$password,$databasename);
     $qry="select * from teachers";
    $resultset= mysqli_query($link,$qry);
?>
<section>
    <div class='container'>
    <div class='row'>
<?php
while($row=mysqli_fetch_assoc($resultset))
{
?>

        <div class='col-md-4 col-sm-4 col-lg-3 m-3' data-aos="zoom-out-up">
    <div class="card" style="width: 200px; box-shadow:1px 1px 3px 1px grey;">
            <div class="card-header bg-dark">Header</div>
            <img src="./Logo/teacher.png" class="card-img-top rounded-circle">
            <div class="card-body bg-dark">
                <h4><?php echo $row['name']; ?></h4>
                <p>
                    Unique_rID: <?php echo $row['uni_ID']; ?><br>
                    mail:<?php echo $row['mail']; ?> <br>
                </p>
            </div>
            <div class="card-footer bg-dark">
            </div>
        </div>
        </div>

<?php
}
?>
            </div>
    </div>
</section>

<?php include_once("./foot.php"); ?>