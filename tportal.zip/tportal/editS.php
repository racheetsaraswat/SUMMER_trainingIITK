<?php include_once("./head.php"); ?>
<?php include_once("./navbar.php"); ?>
<section>
<form method="post" action="<?php echo $_SERVER['PHP_SELF']; ?>">
<div align='center'>
    <?php
        include_once("./db_conn.php");
        $link=mysqli_connect($hostname,$username,$password,$databasename);
        $qry="select name from class_1";
       $resultset= mysqli_query($link,$qry);
    ?>
    <input type="text" name="entry" list="myList">
    <datalist id="myList">
    <?php
    while($row=mysqli_fetch_assoc($resultset))
    {
        echo "<option>$row[name]</option>";
    }
    ?>
</datalist>
    <input type="submit" name="disBtn" value="Dispaly Data">
</div>
<?php
extract($_POST);
if(isset($disBtn))
{
    include_once("./db_conn.php");
    $link=mysqli_connect($hostname,$username,$password,$databasename);
    $qry="select * from class_1 where name='$entry'";
    $resultset= mysqli_query($link,$qry);
    $row=mysqli_fetch_assoc($resultset);
    extract($row);
}
?>

<table class='table table-bordered table-striped mt-3'>
<thead class='table-dark'>
        <tr>
        <td>Roll Number</td><td>
            <input type='text' name='u_roll' value="<?php if(isset($disBtn)) 
            {
                echo $rollno;
            } ?>"></td></tr>
        <tr>
        <td>Name</td><td><input type='text' name='u_name' value="<?php if(isset($disBtn)) 
        {
            echo $name; 
        }?>"></td></tr>
        <tr>
        <td>Marks</td><td><input type='number' name='u_marks' value="<?php if(isset($disBtn)) 
        {
            echo $AvgMks; 
        }?>"></td></tr>
        
        <tr>
        <td colspan=2><input type='submit' name='upBtn' value='upDate'></td></tr>
        </thead>

</table>

</form>
</section>
<?php include_once("./foot.php"); ?>
<?php

if(isset($upBtn))
{
    echo "Works clearly";
    $qry="update class_1 set name='$u_name',AvgMks='$u_marks' where rollno='$u_roll'";
    mysqli_query($link,$qry);
}

?>