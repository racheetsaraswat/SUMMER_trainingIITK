-- phpMyAdmin SQL Dump
-- version 5.2.1
-- https://www.phpmyadmin.net/
--
-- Host: 127.0.0.1
-- Generation Time: Jul 15, 2023 at 12:24 PM
-- Server version: 10.4.28-MariaDB
-- PHP Version: 8.2.4

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `tp_db`
--

-- --------------------------------------------------------

--
-- Table structure for table `class_1`
--

CREATE TABLE `class_1` (
  `rollno` int(11) NOT NULL,
  `name` varchar(25) DEFAULT NULL,
  `AvgMks` int(11) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `class_1`
--

INSERT INTO `class_1` (`rollno`, `name`, `AvgMks`) VALUES
(3, 'Imran', 76),
(11, 'Ravi', 92),
(15, 'Nitin', 65),
(28, 'Rahul', 74),
(47, 'Racheet', 88),
(54, 'nakul', 82),
(56, 'Harsh', 78),
(59, 'Lokesh', 49);

-- --------------------------------------------------------

--
-- Table structure for table `teachers`
--

CREATE TABLE `teachers` (
  `uni_ID` int(11) NOT NULL,
  `name` varchar(25) DEFAULT NULL,
  `mail` varchar(50) DEFAULT NULL,
  `pin` varchar(15) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `teachers`
--

INSERT INTO `teachers` (`uni_ID`, `name`, `mail`, `pin`) VALUES
(1, 'Nikita', 'nikita05@gmail.com', 'nikki@123'),
(2, 'ajitesh', 'ajiteshp@gla.ac.in', 'proct@1414'),
(3, 'mukesh', 'mukeshl@gmail.com', 'muk@1234'),
(4, 'mukul', 'mukuls@gmail.com', 'mukshm@123'),
(5, 'YSingh', 'yogendra@gmail.com', 'Ysingh@1212'),
(6, 'Yogendra', 'ysingh@gmail.com', 'yogi@123'),
(7, 'Danish', 'danishjam@gmail.com', 'jamwal@123');

--
-- Indexes for dumped tables
--

--
-- Indexes for table `class_1`
--
ALTER TABLE `class_1`
  ADD PRIMARY KEY (`rollno`);

--
-- Indexes for table `teachers`
--
ALTER TABLE `teachers`
  ADD PRIMARY KEY (`uni_ID`);

--
-- AUTO_INCREMENT for dumped tables
--

--
-- AUTO_INCREMENT for table `teachers`
--
ALTER TABLE `teachers`
  MODIFY `uni_ID` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=14;
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
