<?php include_once("./head.php"); ?>
<?php include_once("./navbar.php"); ?>

<form method="post" enctype='multipart/form-data'>
<table border="2px" align="center" width="400px" cellspacing="0px">
            <tr><th colspan="2">Students Registration Form</th></tr>
            <!-- <tr><td>Rollno</td><td><input name="roll" size="15" type="number" pattern="[0-9]{3,}"></td></tr> -->
            <tr><td>Name</td><td><input name="nm" placeholder="Enter name" size="15"></td></tr>
            <tr><td>rollno</td><td><input name="rn" type="text"></td></tr>
            <tr><td>Marks</td><td><input name="mks" type="number"></td></tr>
            <tr>
                <td> </td>
                <td><input type="submit" name="subBtn" value="Insert Record">
                </td>
            </tr>
</table>
<?php

extract($_POST);
if(isset($subBtn))
{
     include_once("./db_conn.php");
     $link=mysqli_connect($hostname,$username,$password,$databasename);
     $qry="insert into class_1(rollno,name,AvgMks)values('$rn','$nm','$mks')";
    $r=mysqli_query($link,$qry);
    mysqli_close($link);
    if($r==1)
    {
        echo "<div class='alert alert-success' role='alert'>Record Updated..</div>";
    }
    else
    {
        echo "<div class='alert alert-danger' role='alert'><br> <h4>Failure..</h4></div>";;
    }

}

?>
</form>


<?php 
include_once("./foot.php"); 
?>