<div class='row'>
<div class="card mb-3 mr-5" style="max-width: 540px;" data-aos="zoom-out-up">
  <div class="row no-gutters">
    <div class="col-md-4">
      <img src="./Logo/principal.png" alt="...">
    </div>
    <div class="col-md-8">
      <div class="card-body bg-transparent ml-5 pl-5 text-dark">
        <h5 class="card-title">From Principal's Desk</h5>
        <p class="card-text">I wanted to express my sincere gratitude for your exceptional leadership as our high school principal. Your unwavering commitment to our education and well-being has made a significant impact on our lives. We are truly fortunate to have you as our principal, and we are excited to continue our journey under your exceptional leadership.</p>
      </div>
    </div>
  </div>
</div>
<div class="card mb-3 ml-5" style="max-width: 540px;" data-aos="zoom-out-up">
  <div class="row no-gutters">
    <div class="col-md-4">
      <img src="./Logo/chancellor.png" alt="...">
    </div>
    <div class="col-md-8 ">
      <div class="card-body bg-transparent ml-5 pl-5 text-dark">
        <h5 class="card-title">From Chancellor's Desk</h5>
        <p class="card-text">I wanted to express my sincere gratitude for your exceptional leadership as our high school principal. Your unwavering commitment to our education and well-being has made a significant impact on our lives. We are truly fortunate to have you as our principal, and we are excited to continue our journey under your exceptional leadership.</p>
      </div>
    </div>
  </div>
</div>

</div>