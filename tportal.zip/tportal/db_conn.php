<?php

$hostname="localhost";
$username="root";
$password="";
$databasename="tp_db";

?>