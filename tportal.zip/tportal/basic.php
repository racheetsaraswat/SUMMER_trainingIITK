<?php include_once("./head.php"); ?>

<?php include_once("./navbar.php"); ?>
<?php include_once("./carousel.php"); ?>
<?php include_once("./Act.php"); ?>
<section><div class="accordion bg-transparent" id="AboutUs">
  <div class="card">
    <div class="card-header bg-transparent" id="headingOne">
      <h2 class="mb-0">
        <button class="btn btn-link btn-block text-left bg-transparent" type="button" data-toggle="collapse" data-target="#collapseOne" aria-expanded="true" aria-controls="collapseOne">
          AboutUs
        </button>
      </h2>
    </div>

    <div id="collapseOne" class="collapse show" aria-labelledby="headingOne" data-parent="#AboutUs">
      <div class="card-body bg-transparent">
            <p class='text-dark'>
    Welcome to the Teacher's Login Portal!

We are delighted to provide you with this convenient and efficient platform designed specifically for educators like you. As an esteemed member of our educational community, this portal empowers you to access a range of resources, tools, and information to enhance your teaching experience and support your students' learning journey.

With our user-friendly interface, you can easily navigate through various sections tailored to meet your specific needs. Stay updated on the latest curriculum guidelines, lesson plans, and educational materials curated by experts in the field. Utilize our extensive library of digital resources, including interactive videos, educational games, and engaging worksheets, to create dynamic and immersive learning experiences for your students.

The Teacher's Login Portal also offers a collaborative space, enabling you to connect and share ideas with fellow educators from around the world. Join discussion forums, attend webinars, and participate in professional development courses to expand your knowledge and refine your teaching strategies.

We understand the importance of efficient administrative tasks, which is why our portal provides seamless management of attendance, grading, and student records. Streamline your paperwork and save valuable time, allowing you to focus on what truly matters—nurturing and inspiring young minds.

Rest assured that data security is our utmost priority. We have implemented robust measures to protect your personal information and maintain the confidentiality of student data, ensuring a safe and secure environment for all users.

Thank you for being a part of our dedicated community of educators. We believe that your passion for teaching coupled with the resources and support offered by this portal will unlock endless possibilities for your students. Together, let's empower the next generation through education. Happy teaching!
    </p>
    </div>
    </div>
  </div>
  <div>
</section>

<?php include_once("./foot.php"); ?>