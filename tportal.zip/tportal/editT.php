<?php include_once("./head.php"); ?>
<?php include_once("./navbar.php"); ?>
<section>
<form method="post" action="<?php echo $_SERVER['PHP_SELF']; ?>">
<div align='center'>
    <?php
        include_once("./db_conn.php");
        $link=mysqli_connect($hostname,$username,$password,$databasename);
        $qry="select name from teachers";
       $resultset= mysqli_query($link,$qry);
    ?>
    <input type="text" name="entry" list="myList">
    <datalist id="myList">
    <?php
    while($row=mysqli_fetch_assoc($resultset))
    {
        echo "<option>$row[name]</option>";
    }
    ?>
</datalist>
    <input type="submit" name="disBtn" value="Dispaly Data">
</div>
<?php
extract($_POST);
if(isset($disBtn))
{
    include_once("./db_conn.php");
    $link=mysqli_connect($hostname,$username,$password,$databasename);
    $qry="select * from teachers where name='$entry'";
    $resultset= mysqli_query($link,$qry);
    $row=mysqli_fetch_assoc($resultset);
    extract($row);
}
?>

<table class='table table-bordered table-striped mt-3'>
<thead class='table-dark'>
        <tr>
        <td>Roll Number</td><td>
            <input type='text' name='u_roll' value="<?php if(isset($disBtn)) 
            {
                echo $uni_ID;
            } ?>"></td></tr>
        <tr>
        <td>Name</td><td><input type='text' name='u_name' value="<?php if(isset($disBtn)) 
        {
            echo $name; 
        }?>"></td></tr>
        <tr>
        <td>Email</td><td><input type='email' name='u_mail' value="<?php if(isset($disBtn)) 
        {
            echo $mail; 
        }?>"></td></tr>
        <tr>
        <td>Passcode</td><td><input type='password' name='u_pwd' value="<?php if(isset($disBtn)) 
        {
            echo $pin; 
        }?>"></td></tr>
        
        <tr>
        <td colspan=2><input type='submit' name='upBtn' value='upDate'></td></tr>
        </thead>

</table>

</form>
</section>
<?php include_once("./foot.php"); ?>
<?php

if(isset($upBtn))
{
    echo "Works clearly";
    $qry="update teachers set name='$u_name',mail='$u_mail',pin='$u_pwd' where uni_ID='$u_roll'";
    mysqli_query($link,$qry);
}

?>