<?php include_once("./head.php"); ?>

<?php

if(isset($_SESSION['UserName']))
{
    unset($_SESSION);
    session_destroy();
    header("location:loginTemp.php");
    
}

?>

<?php include_once("./foot.php"); ?>