<nav class="navbar navbar-expand-lg navbar-light bg-transparent">
  <button class="navbar-toggler" type="button" data-toggle="collapse" data-target="#navbarNavDropdown" aria-controls="navbarNavDropdown" aria-expanded="false" aria-label="Toggle navigation">
    <span class="navbar-toggler-icon"></span>
  </button>
  <div class="collapse navbar-collapse" id="navbarNavDropdown">
    <ul class="navbar-nav">
      <li class="nav-item active">
        <a class="nav-link text-white text-white" href="./basic.php">Home <span class="sr-only">(current)</span></a>
      </li>
      <li class="nav-item">
        <a class="nav-link text-white" href="#AboutUs">About Us</a>
      </li>
      <li class="nav-item dropdown">
        <a class="nav-link text-white dropdown-toggle" href="#" role="button" data-toggle="dropdown" aria-expanded="false">
          Contact Us
        </a>
        <div class="dropdown-menu">
          <a class="dropdown-item" href="mailto:racheetsaraswat0705@gmail.com">Mail</a>
          <a class="dropdown-item" href="tel:+918077196688">call</a>
        </div>
      </li>
      <li class="nav-item">
        <a class="nav-link text-white" href="./display.php">Checkout All Teachers</a>
      </li>
      <li class="nav-item">
        <a class="nav-link text-white" href="./displaystu.php">Checkout All Students</a>
      </li>
      <li class="nav-item dropdown">
        <a class="nav-link text-white dropdown-toggle" href="#" role="button" data-toggle="dropdown" aria-expanded="false">
          Edit Teachers Data
        </a>
        <div class="dropdown-menu">
          <a class="dropdown-item" href="AddT.php">Add Teachers</a>
          <a class="dropdown-item" href="editT.php">Edit Teacher Data</a>
        </div>
      </li>
      <li class="nav-item dropdown">
        <a class="nav-link text-white dropdown-toggle" href="#" role="button" data-toggle="dropdown" aria-expanded="false">
          Edit Student Data
        </a>
        <div class="dropdown-menu">
          <a class="dropdown-item" href="addS.php">Add Student</a>
          <a class="dropdown-item" href="editS.php">Edit Student Data</a>
        </div>
      </li>
    </ul>
    <a href="logout.php" class="btn btn-danger ml-5">Logout</a>
  </div>
</nav>